import React from 'react';
import { ChevronLeft, ChevronRight, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';

const categoryData = {
  "TEE'S": [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&q=80",
      title: "Vintage Graphic Tee",
      price: "₱2,250"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&q=80",
      title: "Classic Black Tee",
      price: "₱1,750"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1562157873-818bc0726f68?auto=format&fit=crop&q=80",
      title: "Designer Print Tee",
      price: "₱2,750"
    }
  ],
  'PANTS': [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&q=80",
      title: "Cargo Pants",
      price: "₱4,250"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1584865288642-42078afe6942?auto=format&fit=crop&q=80",
      title: "Denim Jeans",
      price: "₱4,750"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&q=80",
      title: "Track Pants",
      price: "₱3,750"
    }
  ],
  'SHORTS': [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?auto=format&fit=crop&q=80",
      title: "Cargo Shorts",
      price: "₱3,250"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1600489000022-c2086d79f9d4?auto=format&fit=crop&q=80",
      title: "Denim Shorts",
      price: "₱2,750"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1617952385804-7b326fa42766?auto=format&fit=crop&q=80",
      title: "Athletic Shorts",
      price: "₱2,250"
    }
  ],
  'FOOTWEAR': [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80",
      title: "Vintage Sneakers",
      price: "₱6,250"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1600269452121-4f2416e55c28?auto=format&fit=crop&q=80",
      title: "Classic Sneakers",
      price: "₱6,750"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80",
      title: "Modern Sneakers",
      price: "₱7,250"
    }
  ],
  'CAPS': [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&q=80",
      title: "Baseball Cap",
      price: "₱1,750"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1534215754734-18e55d13e346?auto=format&fit=crop&q=80",
      title: "Snapback",
      price: "₱2,250"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1533827432537-70133748f5c8?auto=format&fit=crop&q=80",
      title: "Vintage Cap",
      price: "₱2,750"
    }
  ]
};

function CategoryCarousel() {
  const [activeCategory, setActiveCategory] = React.useState("TEE'S");
  const [currentIndex, setCurrentIndex] = React.useState(0);
  const [isTransitioning, setIsTransitioning] = React.useState(false);
  const categories = Object.keys(categoryData);
  const { addToCart } = useCart();

  const handleTransitionEnd = () => {
    setIsTransitioning(false);
  };

  const next = () => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    const items = categoryData[activeCategory];
    setCurrentIndex((prevIndex) => 
      prevIndex === items.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prev = () => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    const items = categoryData[activeCategory];
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? items.length - 1 : prevIndex - 1
    );
  };

  const handleAddToCart = (item: any) => {
    addToCart({
      id: item.id,
      title: item.title,
      price: item.price,
      image: item.image,
      category: activeCategory
    });
  };

  return (
    <div className="min-h-screen w-full">
      {/* Category Tabs */}
      <div className="w-full mb-6">
        <div className="max-w-2xl mx-auto flex justify-between bg-zinc-800/50 backdrop-blur-sm border border-zinc-700 rounded-lg p-1.5">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => {
                setActiveCategory(category);
                setCurrentIndex(0);
              }}
              className={`
                px-3 py-1.5 text-xs font-medium transition-all duration-300 rounded-md
                ${activeCategory === category 
                  ? 'bg-zinc-100 text-zinc-900 shadow-lg' 
                  : 'text-zinc-100 hover:bg-zinc-700/50'}
              `}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Carousel Content */}
      <div className="relative h-[calc(100vh-200px)]">
        <div className="h-full overflow-hidden">
          <div 
            className="flex h-full transition-transform duration-700 ease-in-out"
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            onTransitionEnd={handleTransitionEnd}
          >
            {categoryData[activeCategory].map((item, index) => (
              <div 
                key={item.id}
                className="w-full flex-shrink-0 px-4"
              >
                <div className="relative h-full overflow-hidden">
                  <img 
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover transition-transform duration-700 ease-in-out"
                    style={{
                      transform: `scale(${currentIndex === index ? '1' : '1.1'})`,
                      opacity: currentIndex === index ? '1' : '0.8'
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-900/90 via-zinc-900/40 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-8">
                    <div className="max-w-4xl mx-auto">
                      <div className="text-left mb-4">
                        <h3 className="text-xl font-bold mb-1 text-zinc-100/90 transition-all duration-700 transform"
                            style={{
                              opacity: currentIndex === index ? '1' : '0',
                              transform: `translateY(${currentIndex === index ? '0' : '20px'})`
                            }}
                        >{item.title}</h3>
                        <p className="text-base text-zinc-400 transition-all duration-700 delay-100 transform"
                           style={{
                             opacity: currentIndex === index ? '1' : '0',
                             transform: `translateY(${currentIndex === index ? '0' : '20px'})`
                           }}
                        >{item.price}</p>
                      </div>
                      <div className="flex justify-center">
                        <button 
                          onClick={() => handleAddToCart(item)}
                          className="bg-zinc-100 text-zinc-900 px-4 py-1.5 text-sm rounded-none hover:bg-yellow-400 transition-all duration-300 flex items-center space-x-2 group transform"
                          style={{
                            opacity: currentIndex === index ? '1' : '0',
                            transform: `translateY(${currentIndex === index ? '0' : '20px'})`
                          }}
                          aria-label={`Add ${item.title} to cart`}
                        >
                          <ShoppingBag size={14} className="transition-transform group-hover:scale-110" />
                          <span>ADD TO CART</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Navigation Arrows */}
        <button 
          onClick={prev}
          className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/20 backdrop-blur-sm p-3 rounded-full hover:bg-black/40 transition-all duration-300 transform hover:scale-110"
          disabled={isTransitioning}
          style={{ opacity: isTransitioning ? '0.5' : '1' }}
        >
          <ChevronLeft size={24} className="text-white/90" />
        </button>
        
        <button 
          onClick={next}
          className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/20 backdrop-blur-sm p-3 rounded-full hover:bg-black/40 transition-all duration-300 transform hover:scale-110"
          disabled={isTransitioning}
          style={{ opacity: isTransitioning ? '0.5' : '1' }}
        >
          <ChevronRight size={24} className="text-white/90" />
        </button>

        {/* Dots Navigation */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
          {categoryData[activeCategory].map((_, index) => (
            <button
              key={index}
              onClick={() => {
                if (!isTransitioning) {
                  setIsTransitioning(true);
                  setCurrentIndex(index);
                }
              }}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                currentIndex === index 
                  ? 'bg-white w-4' 
                  : 'bg-white/50 hover:bg-white/70'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default CategoryCarousel;