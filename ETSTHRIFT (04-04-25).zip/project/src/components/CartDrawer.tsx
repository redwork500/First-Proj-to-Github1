import React from 'react';
import { X, Plus, Minus, Trash2 } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function CartDrawer() {
  const { 
    items, 
    removeFromCart, 
    updateQuantity, 
    cartVisible, 
    setCartVisible,
    totalItems 
  } = useCart();

  if (!cartVisible) return null;

  const total = items.reduce((sum, item) => {
    const price = parseFloat(item.price.replace('₱', '').replace(',', ''));
    return sum + (price * item.quantity);
  }, 0);

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
        onClick={() => setCartVisible(false)}
      />

      {/* Cart Drawer */}
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-zinc-900 shadow-xl z-50 transform transition-transform duration-300">
        <div className="p-6 h-full flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold flex items-center gap-2">
              Shopping Cart
              {totalItems > 0 && (
                <span className="text-sm bg-yellow-400 text-black px-2 py-1 rounded-full">
                  {totalItems}
                </span>
              )}
            </h2>
            <button 
              onClick={() => setCartVisible(false)}
              className="text-zinc-400 hover:text-zinc-100 transition"
              aria-label="Close cart"
            >
              <X size={24} />
            </button>
          </div>

          {items.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-zinc-400">
              Your cart is empty
            </div>
          ) : (
            <>
              <div className="flex-1 overflow-y-auto">
                {items.map((item) => (
                  <div 
                    key={item.id} 
                    className="flex gap-4 border-b border-zinc-800 py-4"
                  >
                    <img 
                      src={item.image} 
                      alt={item.title}
                      className="w-20 h-20 object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-medium">{item.title}</h3>
                      <p className="text-zinc-400 text-sm">{item.category}</p>
                      <p className="text-yellow-400">{item.price}</p>
                      
                      <div className="flex items-center gap-2 mt-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-zinc-800 rounded transition"
                          aria-label="Decrease quantity"
                        >
                          <Minus size={16} />
                        </button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-zinc-800 rounded transition"
                          aria-label="Increase quantity"
                        >
                          <Plus size={16} />
                        </button>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="ml-auto p-1 text-red-400 hover:bg-red-400/10 rounded transition"
                          aria-label="Remove item"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-zinc-800">
                <div className="flex justify-between mb-4">
                  <span>Total</span>
                  <span className="font-bold">₱{total.toLocaleString()}</span>
                </div>
                <button className="w-full bg-yellow-400 text-black py-3 font-medium hover:bg-yellow-500 transition rounded-md">
                  Checkout
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}