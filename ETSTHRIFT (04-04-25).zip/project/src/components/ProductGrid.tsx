import React from 'react';

const products = [
  {
    id: 1,
    name: 'Urban Tech Jacket',
    price: '$245',
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80'
  },
  {
    id: 2,
    name: 'Street Cargo Pants',
    price: '$175',
    image: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?auto=format&fit=crop&q=80'
  },
  {
    id: 3,
    name: 'Premium Sneakers',
    price: '$225',
    image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80'
  },
  {
    id: 4,
    name: 'Graphic Hoodie',
    price: '$145',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80'
  },
  {
    id: 5,
    name: 'Urban Backpack',
    price: '$95',
    image: 'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?auto=format&fit=crop&q=80'
  },
  {
    id: 6,
    name: 'Street Cap',
    price: '$45',
    image: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&q=80'
  }
];

function ProductGrid() {
  return (
    <section className="py-20 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold mb-12 text-center">TRENDING NOW</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <div key={product.id} className="group">
              <div className="relative h-[400px] overflow-hidden mb-4">
                <img 
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition duration-700 group-hover:scale-110"
                />
                <button className="absolute bottom-0 left-0 right-0 bg-zinc-900/90 py-4 translate-y-full group-hover:translate-y-0 transition duration-300">
                  ADD TO CART
                </button>
              </div>
              <h3 className="text-lg font-bold mb-2">{product.name}</h3>
              <p className="text-zinc-400">{product.price}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default ProductGrid;