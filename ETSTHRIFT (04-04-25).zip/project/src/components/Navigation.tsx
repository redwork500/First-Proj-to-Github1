import React from 'react';
import { Menu, X, Instagram, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface NavigationProps {
  isMenuOpen: boolean;
  setIsMenuOpen: (isOpen: boolean) => void;
  onShowShippingInfo: () => void;
  onShowReturns: () => void;
  onShowContactInfo: () => void;
  onShowLocations: () => void;
}

function Navigation({ 
  isMenuOpen, 
  setIsMenuOpen,
  onShowShippingInfo,
  onShowReturns,
  onShowContactInfo,
  onShowLocations 
}: NavigationProps) {
  const { totalItems, setCartVisible } = useCart();

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-zinc-900/95 backdrop-blur-sm border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="w-1/4">
              <button 
                className="lg:hidden"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
              
              <div className="hidden lg:flex items-center space-x-8">
                <a 
                  href="#"
                  className="text-sm tracking-wider hover:text-zinc-300 transition"
                >
                  NEW COLLECTIONS
                </a>
              </div>
            </div>

            <div className="w-1/2 flex justify-center">
              <h1 className="text-[1.5rem] font-bold tracking-tighter">ETS THRIFTS</h1>
            </div>

            <div className="w-1/4 flex items-center justify-end space-x-6">
              <a 
                href="https://www.instagram.com/jhyrickjaymagbanua/"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-zinc-300 transition"
              >
                <Instagram size={20} />
              </a>
              <button 
                onClick={() => setCartVisible(true)}
                className="hover:text-zinc-300 transition relative"
                aria-label="Shopping cart"
              >
                <ShoppingBag size={25} />
                {totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-yellow-400 text-black w-5 h-5 rounded-full flex items-center justify-center text-xs font-medium">
                    {totalItems}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div 
        className={`fixed inset-0 z-40 bg-zinc-900 transform ${
          isMenuOpen ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-300 lg:hidden overflow-y-auto`}
      >
        <div className="p-8 pt-24">
          {/* SHOP Section */}
          <div className="mb-8">
            <h4 className="text-2xl font-bold mb-4">SHOP</h4>
            <ul className="space-y-4">
              <li>
                <a href="#" className="text-xl hover:text-zinc-300 transition">
                  New Collections
                </a>
              </li>
              <li>
                <a href="#" className="text-xl hover:text-zinc-300 transition">
                  Sale Items
                </a>
              </li>
            </ul>
          </div>

          {/* HELP Section */}
          <div className="mb-8">
            <h4 className="text-2xl font-bold mb-4">HELP</h4>
            <ul className="space-y-4">
              <li>
                <button 
                  onClick={onShowShippingInfo}
                  className="text-xl hover:text-zinc-300 transition"
                >
                  Shipping Info
                </button>
              </li>
              <li>
                <button 
                  onClick={onShowContactInfo}
                  className="text-xl hover:text-zinc-300 transition"
                >
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          {/* ABOUT Section */}
          <div>
            <h4 className="text-2xl font-bold mb-4">ABOUT</h4>
            <ul className="space-y-4">
              <li>
                <a href="#" className="text-xl hover:text-zinc-300 transition">
                  Our Story
                </a>
              </li>
              <li>
                <button 
                  onClick={onShowLocations}
                  className="text-xl hover:text-zinc-300 transition"
                >
                  Locations
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}

export default Navigation;