import React, { useState } from 'react';
import Navigation from './components/Navigation';
import CategoryCarousel from './components/CategoryCarousel';
import CartDrawer from './components/CartDrawer';
import { CartProvider } from './context/CartContext';
import { X } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showShippingInfo, setShowShippingInfo] = useState(false);
  const [showContactInfo, setShowContactInfo] = useState(false);
  const [showLocations, setShowLocations] = useState(false);
  const [showReturns, setShowReturns] = useState(false);

  const scrollToCategories = () => {
    const categoriesSection = document.getElementById('categories');
    if (categoriesSection) {
      categoriesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <CartProvider>
      <div className="min-h-screen bg-gradient-to-b from-zinc-900 via-zinc-900 to-zinc-900 text-zinc-100">
        {/* Fixed Navigation */}
        <Navigation 
          isMenuOpen={isMenuOpen} 
          setIsMenuOpen={setIsMenuOpen}
          onShowShippingInfo={() => setShowShippingInfo(true)}
          onShowReturns={() => setShowReturns(true)}
          onShowContactInfo={() => setShowContactInfo(true)}
          onShowLocations={() => setShowLocations(true)}
        />

        {/* Cart Drawer */}
        <CartDrawer />

        {/* Hero Section */}
        <section className="relative h-screen">
          <div className="absolute inset-0 backdrop-blur-md">
            <img 
              src="https://goesnhvrgh.ufs.sh/f/hjFp5ZGP8mXufsjllaga5FIst9j7ldTXeVSAZC0KGghWcroN"
              alt="Hero"
              className="absolute inset-0 w-full h-full object-cover opacity-80"
            />
            {/* Vignette effect */}
            <div className="absolute inset-0 bg-radial-gradient" />
          </div>
          <div className="absolute inset-0 bg-gradient-to-b from-zinc-900/70 via-zinc-900/60 to-zinc-900/90" />
          <div className="absolute inset-0 flex items-center justify-center" style={{ paddingTop: '4rem' }}>
            <div className="text-center px-4">
              <h1 className="text-5xl md:text-7xl font-bold mb-2 tracking-tighter">ETS THRIFTS</h1>
              <p className="text-[0.85em] md:text-[0.85em] mb-1 text-zinc-300">Premium Thrifts Collected For You</p>
              <p className="text-[0.85em] md:text-[0.85em] mb-3 text-zinc-400 italic">"trust God, stay humble."</p>
              <button 
                onClick={scrollToCategories}
                className="bg-zinc-100 text-zinc-900 px-6 py-2 rounded-none hover:bg-[#262525] hover:text-zinc-100 transition-all duration-300 text-sm"
              >
                SHOP NOW
              </button>
            </div>
          </div>
        </section>

        {/* About Us Section */}
        <section className="relative py-16 bg-gradient-to-b from-zinc-900 via-zinc-800 to-zinc-900">
          <div className="absolute inset-0">
            <img 
              src="https://goesnhvrgh.ufs.sh/f/hjFp5ZGP8mXuzky5jXpOClj1Rh9MDwNn0Gr32uAJVyHFXPT4"
              alt="About Background"
              className="w-full h-full object-cover opacity-30"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-zinc-900/90 via-zinc-800/80 to-zinc-900/90" />
          </div>
          <div className="relative max-w-4xl mx-auto px-8">
            <div className="backdrop-blur-sm bg-zinc-900/20 p-8 rounded-lg">
              <h2 className="text-3xl font-bold mb-6 text-center text-white">ABOUT US</h2>
              <p className="text-lg md:text-xl leading-relaxed text-zinc-100 tracking-wide text-center">
                "ETS THRIFTS" started as a hobby at first, getting that quality item for a budget price. eventually the love for luckily getting a banger item for a very affordable price improved as time went on. we hope you find our product worth buying, at "ETS THRIFTS" we're all about promoting positivity and humbleness.
              </p>
            </div>
          </div>
        </section>

        {/* Categories Section */}
        <section id="categories" className="py-8 px-4 md:px-8 bg-gradient-to-b from-zinc-900 via-zinc-800 to-zinc-900 scroll-mt-20">
          <h2 className="text-3xl font-bold mb-6 text-center">CATEGORIES</h2>
          <CategoryCarousel />
        </section>

        {/* Footer - Reduced vertical space */}
        <footer className="bg-gradient-to-b from-zinc-900 to-zinc-800 py-2 px-4 md:px-8">
          <div className="max-w-7xl mx-auto grid grid-cols-3 gap-1">
            <div className="text-center md:text-left">
              <h4 className="text-xs font-bold mb-0.5">SHOP</h4>
              <ul className="space-y-0.5 text-zinc-400 text-[10px]">
                <li className="hover:text-zinc-100 cursor-pointer transition">New Collections</li>
                <li className="hover:text-zinc-100 cursor-pointer transition">Sale Items</li>
              </ul>
            </div>
            <div className="text-center md:text-left">
              <h4 className="text-xs font-bold mb-0.5">HELP</h4>
              <ul className="space-y-0.5 text-zinc-400 text-[10px]">
                <li 
                  className="hover:text-zinc-100 cursor-pointer transition"
                  onClick={() => setShowShippingInfo(true)}
                >
                  Shipping Info
                </li>
                <li 
                  className="hover:text-zinc-100 cursor-pointer transition"
                  onClick={() => setShowContactInfo(true)}
                >
                  Contact Us
                </li>
              </ul>
            </div>
            <div className="text-center md:text-left">
              <h4 className="text-xs font-bold mb-0.5">ABOUT</h4>
              <ul className="space-y-0.5 text-zinc-400 text-[10px]">
                <li className="hover:text-zinc-100 cursor-pointer transition">Our Story</li>
                <li 
                  className="hover:text-zinc-100 cursor-pointer transition"
                  onClick={() => setShowLocations(true)}
                >
                  Locations
                </li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto mt-1 pt-1 border-t border-zinc-700">
            <p className="text-zinc-400 text-center text-[10px]">© {new Date().getFullYear()} Ets Thrifts. All rights reserved.</p>
          </div>
        </footer>

        {/* Modals */}
        {showShippingInfo && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-zinc-800 p-8 max-w-md mx-4 relative transform transition-all duration-300 scale-100">
              <button 
                onClick={() => setShowShippingInfo(false)}
                className="absolute top-4 right-4 text-zinc-400 hover:text-zinc-100"
              >
                <X size={24} />
              </button>
              <h3 className="text-xl font-bold mb-4">Shipping Information</h3>
              <p className="text-zinc-300">We ship nationwide through J&T shipping fee applies.</p>
            </div>
          </div>
        )}

        {showContactInfo && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-zinc-800 p-8 max-w-md mx-4 relative transform transition-all duration-300 scale-100">
              <button 
                onClick={() => setShowContactInfo(false)}
                className="absolute top-4 right-4 text-zinc-400 hover:text-zinc-100"
              >
                <X size={24} />
              </button>
              <h3 className="text-xl font-bold mb-4">Contact Us</h3>
              <p className="text-zinc-300">Clicking the Instagram Icon on the upper right corner.</p>
            </div>
          </div>
        )}

        {showLocations && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-zinc-800 p-8 max-w-md mx-4 relative transform transition-all duration-300 scale-100">
              <button 
                onClick={() => setShowLocations(false)}
                className="absolute top-4 right-4 text-zinc-400 hover:text-zinc-100"
              >
                <X size={24} />
              </button>
              <h3 className="text-xl font-bold mb-4">Our Location</h3>
              <p className="text-zinc-300">⚲ Cuartero Capiz</p>
            </div>
          </div>
        )}
      </div>
    </CartProvider>
  );
}

export default App;