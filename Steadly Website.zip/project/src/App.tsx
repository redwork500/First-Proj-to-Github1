import React, { useState, useEffect } from 'react';
import { Instagram, X, ChevronLeft, ChevronRight, Home, Info, Grid, MessageCircle } from 'lucide-react';

function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('home');

  const cards = [
    {
      id: 1,
      image: "https://goesnhvrgh.ufs.sh/f/hjFp5ZGP8mXuW3O0tUu9zkvPuBhx8R0pVZqLmfC37bFw5KNH",
      title: "Custom Design Stickers"
    },
    {
      id: 2,
      image: "https://goesnhvrgh.ufs.sh/f/hjFp5ZGP8mXuDiEWRwLAVi1hCLebcPkSaK7g90InYUTw2qDx",
      title: "The Panic Factory"
    },
    {
      id: 3,
      image: "https://goesnhvrgh.ufs.sh/f/hjFp5ZGP8mXubmmwr9UV2G4ikjdJYsztK58LRmWaIpXZg61H",
      title: "Premium Collections"
    },
    {
      id: 4,
      image: "https://goesnhvrgh.ufs.sh/f/hjFp5ZGP8mXuRTCkZ1x1P0o4IvfKZ3jhD7C5BgHLwsnu8OlW",
      title: "Mansion Mosquito"
    }
  ];

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 100);

      // Update active tab based on scroll position
      const sections = {
        home: 0,
        about: document.getElementById('about')?.offsetTop || 0,
        collection: document.getElementById('collection')?.offsetTop || 0
      };

      const currentPosition = window.scrollY + window.innerHeight / 3;

      if (currentPosition < sections.about) {
        setActiveTab('home');
      } else if (currentPosition < sections.collection) {
        setActiveTab('about');
      } else {
        setActiveTab('collection');
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNext = () => {
    if (currentIndex < cards.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (touchStart - touchEnd > 75 && currentIndex < cards.length - 1) {
      handleNext();
    }
    if (touchStart - touchEnd < -75 && currentIndex > 0) {
      handlePrev();
    }
  };

  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToHome = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setActiveTab('home');
  };

  const scrollToAbout = () => {
    scrollToSection('about');
    setActiveTab('about');
  };

  const scrollToCollection = () => {
    scrollToSection('collection');
    setActiveTab('collection');
  };

  const NavLinks = () => (
    <nav className="hidden md:flex items-center space-x-1">
      <button 
        onClick={scrollToAbout}
        className="relative px-6 py-2 group"
      >
        <span className="absolute inset-0 w-full h-full transition duration-300 ease-out transform translate-x-1 translate-y-1 bg-[#D90429] group-hover:-translate-x-0 group-hover:-translate-y-0"></span>
        <span className="absolute inset-0 w-full h-full bg-black border-2 border-[#D90429] group-hover:bg-[#D90429]"></span>
        <span className="relative text-[#D90429] group-hover:text-white font-bold">ABOUT</span>
      </button>
      <button 
        onClick={scrollToCollection}
        className="relative px-6 py-2 group"
      >
        <span className="absolute inset-0 w-full h-full transition duration-300 ease-out transform translate-x-1 translate-y-1 bg-[#30B8B8] group-hover:-translate-x-0 group-hover:-translate-y-0"></span>
        <span className="absolute inset-0 w-full h-full bg-black border-2 border-[#30B8B8] group-hover:bg-[#30B8B8]"></span>
        <span className="relative text-[#30B8B8] group-hover:text-white font-bold">COLLECTION</span>
      </button>
      <button 
        onClick={() => setIsContactOpen(true)}
        className="relative px-6 py-2 group"
      >
        <span className="absolute inset-0 w-full h-full transition duration-300 ease-out transform translate-x-1 translate-y-1 bg-[#D90429] group-hover:-translate-x-0 group-hover:-translate-y-0"></span>
        <span className="absolute inset-0 w-full h-full bg-black border-2 border-[#D90429] group-hover:bg-[#D90429]"></span>
        <span className="relative text-[#D90429] group-hover:text-white font-bold">CONTACT</span>
      </button>
    </nav>
  );

  return (
    <div className="min-h-screen bg-black text-white flex flex-col pb-16 md:pb-0">
      {/* Mobile Tab Bar */}
      <div className="mobile-tab-bar">
        <div className="flex justify-around items-center">
          <button
            onClick={scrollToHome}
            className={`tab-button ${activeTab === 'home' ? 'active' : ''}`}
          >
            <Home size={24} />
            <span className="text-xs mt-1">Home</span>
          </button>
          <button
            onClick={scrollToAbout}
            className={`tab-button ${activeTab === 'about' ? 'active' : ''}`}
          >
            <Info size={24} />
            <span className="text-xs mt-1">About</span>
          </button>
          <button
            onClick={scrollToCollection}
            className={`tab-button ${activeTab === 'collection' ? 'active' : ''}`}
          >
            <Grid size={24} />
            <span className="text-xs mt-1">Collection</span>
          </button>
          <button
            onClick={() => setIsContactOpen(true)}
            className={`tab-button ${isContactOpen ? 'active' : ''}`}
          >
            <MessageCircle size={24} />
            <span className="text-xs mt-1">Contact</span>
          </button>
        </div>
      </div>

      {/* Contact Pop-out */}
      <div 
        className={`fixed inset-0 z-50 flex items-center justify-center transition-opacity duration-300 ${
          isContactOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setIsContactOpen(false)} />
        <div 
          className={`relative bg-black border-2 border-[#D90429] p-8 max-w-lg w-full mx-4 transform transition-all duration-500 ${
            isContactOpen ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
          }`}
        >
          <button
            onClick={() => setIsContactOpen(false)}
            className="absolute top-4 right-4 text-[#30B8B8] hover:text-[#D90429] transition-colors"
          >
            <X size={24} />
          </button>
          <div className="text-center">
            <h3 className="text-2xl font-black mb-6 steadly-text bg-gradient-to-r from-[#D90429] to-[#30B8B8] text-transparent bg-clip-text">
              REACH OUT
            </h3>
            <p className="text-lg font-bold leading-relaxed" style={{
              textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
            }}>
              Want to contact us? Just click our Instagram icon on the upper-right side or the icon below fam. Talk to you soon, Godbless!
            </p>
            <div className="mt-6 flex justify-center">
              <a 
                href="https://www.instagram.com/steadly_corp/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 bg-gradient-to-r from-[#D90429] to-[#30B8B8] p-[2px] rounded-full hover:scale-105 transition-transform duration-300"
              >
                <div className="bg-black rounded-full px-6 py-2 flex items-center space-x-2">
                  <Instagram className="w-6 h-6" />
                  <span className="font-bold">@steadly_corp</span>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Header */}
      <div className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 transform ${
        isScrolled ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'
      }`}>
        <header className="bg-black/90 backdrop-blur-sm border-b-4 border-[#D90429] shadow-xl">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-black tracking-tight">
                <span className="text-[#D90429]">STEADLY</span>
                <span className="text-[#30B8B8]">CORP</span>
              </h2>
              <NavLinks />
              <div className="flex items-center">
                <a href="https://www.instagram.com/steadly_corp/" target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-[#30B8B8]/10 rounded-full transition-colors text-[#30B8B8] hover:text-[#D90429]">
                  <Instagram className="w-6 h-6" />
                </a>
              </div>
            </div>
          </div>
        </header>
      </div>

      {/* Main Header */}
      <header className="gradient-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              {/* Empty div to maintain layout */}
            </div>
            <NavLinks />
            <div className="flex items-center">
              <a href="https://www.instagram.com/steadly_corp/" target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-[#30B8B8]/10 rounded-full transition-colors text-[#30B8B8] hover:text-[#D90429]">
                <Instagram className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-grow" id="home">
        <div className="relative overflow-hidden">
          <div className="absolute inset-0">
            <img
              src="https://goesnhvrgh.ufs.sh/f/hjFp5ZGP8mXuIO4wKW7HUYBroLdupTn83MfaWP1OJZ5qxQDv"
              alt="Urban Street Art Scene"
              className="w-full h-full object-cover opacity-60 scale-105 animate-subtle-zoom"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/60 to-black/90" />
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-28 md:py-44">
            <div className="relative z-10 text-center">
              <h2 className="text-3xl md:text-6xl font-black mb-6 tracking-tight filter drop-shadow-[0_5px_5px_rgba(217,4,41,0.3)]">
                <span className="steadly-text text-[#D90429]">STEADLY</span>
                <span className="corp-text">CORP</span>
              </h2>
              <p className="text-lg md:text-xl font-bold mb-10 tracking-wide" style={{
                textShadow: '-1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000'
              }}>
                <span className="text-[#D90429]">🔥 Fresh Tees & Stickers.</span>{" "}
                <span className="text-[#30B8B8]">Built for the streets.</span>{" "}
                <span className="text-[#D90429]">Stay unique. 🔥</span>
              </p>
              <button className="bg-[#D90429] hover:bg-[#30B8B8] text-white px-10 py-3 rounded-none font-bold text-base uppercase transition-all duration-300 hover:shadow-lg hover:scale-105 border-2 border-black">
                Shop Now
              </button>
            </div>
          </div>
        </div>

        {/* About Section */}
        <section id="about" className="relative py-24 bg-black">
          <div className="absolute inset-0">
            <img
              src="https://goesnhvrgh.ufs.sh/f/hjFp5ZGP8mXuM0xb7jFgMqltNRSJxd1T4iyPuvArHpozB8s9"
              alt="Street Art Scene"
              className="w-full h-full object-cover opacity-75"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black via-black/80 to-black" />
          </div>
          <div className="relative max-w-4xl mx-auto px-6">
            <div className="text-center">
              <h2 className="text-3xl font-black mb-8 steadly-text">
                <span className="text-[#D90429]">ABOUT</span>
                <span className="text-[#30B8B8]"> US</span>
              </h2>
              <p className="text-lg md:text-xl font-bold leading-relaxed tracking-wide text-white/90" style={{
                textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
              }}>
                Steadly is a streetwear brand bringin' you exclusive tees and custom design stickers for those who know and encourage the streets positives, keep it simple but real. It's all about that effortless style with a raw edge.
              </p>
            </div>
          </div>
        </section>

        {/* Collection Section */}
        <section id="collection" className="relative py-24 bg-black">
          <div className="absolute inset-0">
            <img
              src="https://goesnhvrgh.ufs.sh/f/hjFp5ZGP8mXu4MkThiwPIKxFDd9TUGM3pQ7bmkB4WrvfNa08"
              alt="Collection Background"
              className="w-full h-full object-cover opacity-30"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black via-black/60 to-black" />
          </div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-black mb-12 steadly-text text-center bg-gradient-to-r from-[#D90429] to-[#30B8B8] text-transparent bg-clip-text">
              COLLECTIONS
            </h2>
            <div className="relative">
              <div 
                className="overflow-hidden relative"
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
              >
                <div 
                  className="flex transition-transform duration-500 ease-out"
                  style={{ transform: `translateX(-${currentIndex * 100}%)` }}
                >
                  {cards.map((card) => (
                    <div key={card.id} className="w-full flex-shrink-0">
                      <div className="relative bg-gradient-to-br from-[#D90429] via-[#30B8B8] to-[#D90429] p-[2px] rounded-lg mx-auto max-w-2xl">
                        <div className="bg-black rounded-lg overflow-hidden">
                          <div className="relative h-[60vh] overflow-hidden">
                            <img
                              src={card.image}
                              alt={card.title}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
                          </div>
                          <div className="p-4">
                            <h3 className="text-xl font-black text-white text-center">{card.title}</h3>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Navigation Arrows */}
              <button 
                onClick={handlePrev}
                className={`absolute left-4 top-1/2 transform -translate-y-1/2 p-2 rounded-full text-white transition-colors ${
                  currentIndex === 0 
                    ? 'bg-black/30 cursor-not-allowed' 
                    : 'bg-black/50 hover:bg-[#D90429]'
                }`}
                disabled={currentIndex === 0}
              >
                <ChevronLeft size={24} />
              </button>
              <button 
                onClick={handleNext}
                className={`absolute right-4 top-1/2 transform -translate-y-1/2 p-2 rounded-full text-white transition-colors ${
                  currentIndex === cards.length - 1 
                    ? 'bg-black/30 cursor-not-allowed' 
                    : 'bg-black/50 hover:bg-[#D90429]'
                }`}
                disabled={currentIndex === cards.length - 1}
              >
                <ChevronRight size={24} />
              </button>

              {/* Indicator Dots */}
              <div className="flex justify-center mt-4 space-x-2">
                {cards.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index === currentIndex ? 'bg-[#D90429]' : 'bg-gray-500'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-black border-t-4 border-[#30B8B8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-lg font-bold">
              © 2025 <span className="text-[#D90429]">Steadly</span><span className="text-[#30B8B8]">Corp</span>. Keep it real. Keep it creative.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;